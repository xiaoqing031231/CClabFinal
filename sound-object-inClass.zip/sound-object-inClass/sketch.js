// sounds from:
// https://freesound.org/people/GowlerMusic/sounds/266566/
// https://freesound.org/people/cfork/sounds/8000/
// https://freesound.org/people/ccolbert70Eagles23/sounds/423526/


let bodies = [];

function preload(){
    for(let i = 0; i < 3; i++){
        bodies.push( loadImage("bodies/body_"+i+".png"))
    }
}

function setup(){
    let cnv = createCanvas(400, 400);
    cnv.parent("canvasContainer");  

}

function draw(){
    background(120, 40, 240);

    image(bodies[0], 0, 0);
}


class Creature{
    constructor(x_, y_){
        this.x = x_;
        this.y = y_;
        this.xSpeed = random(-2, 2);
        this.ySpeed = random(2, 2);

    }
    update(){
        this.x += this.xSpeed;
        this.y += this.ySpeed;
    }
    display(){
        push();
        translate(this.x, this.y)
        
        

        pop();
    }
}

